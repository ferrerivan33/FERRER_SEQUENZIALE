package ferrer;

public class Main {

	public static void main(String[] args) {
		// Creazione dell'oggetto Minuscolo
		Minuscolo min = new Minuscolo();

		// Chiamata al metodo leggi che include la logica di trasformazione
		min.leggi();

		// Stampa della parola trasformata in minuscolo
		System.out.println("Parola trasformata in minuscolo: " + min.getParolaMinuscola());
	}
}
