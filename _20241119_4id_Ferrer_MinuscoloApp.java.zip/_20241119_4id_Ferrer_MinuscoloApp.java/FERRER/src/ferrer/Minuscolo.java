package ferrer;

import java.util.Scanner;

public class Minuscolo {
    // Attributi
    private String parola; // La parola letta dall'utente
    private char[] caratteriMinuscoli; // Array di caratteri trasformati in minuscolo

    // Costruttore
    public Minuscolo() {
        this.parola = "";
    }

    // Metodo per leggere la parola
    public void leggi() {
        Scanner in = new Scanner(System.in);
        System.out.println("\nInserisci una parola: ");
        this.parola = in.next(); // Legge la parola
        trasformaInMinuscolo(); // Trasforma la parola in minuscolo
    }

    // Metodo per trasformare la parola in un array di caratteri in minuscolo
    private void trasformaInMinuscolo() {
        caratteriMinuscoli = new char[parola.length()];
        for (int x = 0; x < parola.length(); x++) {
            caratteriMinuscoli[x] = Character.toLowerCase(parola.charAt(x));
        }
    }

    // Metodo per ottenere la parola trasformata come stringa
    public String getParolaMinuscola() {
        return new String(caratteriMinuscoli);
    }
}
